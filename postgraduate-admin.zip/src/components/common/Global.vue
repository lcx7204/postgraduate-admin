<script>
    name:'Global'
    const serverUrl = "http://kaoyan.natapp1.cc/Postgraduates";    //服务器地址
    export default {
        name: "Global",
        serverUrl,
    }
</script>